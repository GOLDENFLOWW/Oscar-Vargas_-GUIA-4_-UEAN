
package universidadean.empleo.mundo;

import java.util.ArrayList;


public class BolsaDeEmpleo {
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

   
    private ArrayList<Aspirante> aspirantes;

    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------

   
    public BolsaDeEmpleo() {
        aspirantes = new ArrayList<>();
    }

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------

   
    public ArrayList<Aspirante> darAspirantes() {
        ArrayList<Aspirante> copia = new ArrayList<>(aspirantes);
        return copia;
    }

  

    public boolean agregarAspirante(String nombreA, String profesionA, int aniosExperienciaA, int edadA, String telefonoA, String imagenA,String cedulaA) {
        int aspiranteBuscado = buscarAspirante(nombreA);
        boolean agregado = false;
        if (aspiranteBuscado == -1) {
            Aspirante nuevoAspirante = new Aspirante(nombreA, profesionA, aniosExperienciaA, edadA, telefonoA, imagenA, cedulaA);
            aspirantes.add(nuevoAspirante);
            agregado = true;
        }

        return agregado;
    }

     
    public void ordenarPorNombre() {
        

        int n = this.aspirantes.size();
        Aspirante temp;

        for (int i = 0; i < n; i++) {
            for (int j =  i +1; j < n; j++) {

                if (this.aspirantes.get(j).darNombre().compareToIgnoreCase(this.aspirantes.get(i).darNombre())<0) {

                    temp = this.aspirantes.get(i);

                    this.aspirantes.set(i, this.aspirantes.get(j));
                    this.aspirantes.set(j, temp);

                }
            }
        }

    }

     
    public void ordenarPorEdad() {
         
        int i, j, pos;
        Aspirante menor, tmp;
        int n = this.aspirantes.size();
        for (i = 0; i < n - 1; i++) {
            menor = this.aspirantes.get(i);
            pos = i;
            for (j = i + 1; j < n; j++){
                if (this.aspirantes.get(j).darEdad() < menor.darEdad()) {
                    menor = this.aspirantes.get(j);
                    pos = j;
                }
            }
            if (pos != i){
                tmp = this.aspirantes.get(i);
                this.aspirantes.set(i,this.aspirantes.get(pos));
                this.aspirantes.set(pos,tmp);
            }
        }
    }

   
    public void ordenarPorProfesion() {
         
        int n = this.aspirantes.size();
        Aspirante temp;

        for (int i = 0; i < n; i++) {
            for (int j =  i +1; j < n; j++) {


                if (this.aspirantes.get(j).darProfesion().compareToIgnoreCase(this.aspirantes.get(i).darProfesion())<0) {

                    temp = this.aspirantes.get(i);

                    this.aspirantes.set(i, this.aspirantes.get(j));
                    this.aspirantes.set(j, temp);

                }
            }
        }

    }

    
    public void ordenarPorAniosDeExperiencia() {
        
        int p, j;
        Aspirante temp;
        int n = this.aspirantes.size();
        for (p = 1; p < n; p++){
            temp = this.aspirantes.get(p);
            j = p - 1;
            while ((j >= 0) && (temp.darAniosExperiencia() < this.aspirantes.get(j).darAniosExperiencia())){
                this.aspirantes.set(j + 1,  this.aspirantes.get(j));
                j--;
            }
            this.aspirantes.set(j + 1,temp);
        }
    }

  
    public int buscarAspirante(String nombre) {
        int posicion = -1;

         
        int i = 0;
        for (Aspirante a: aspirantes) {
            if (a.darNombre().equalsIgnoreCase(nombre)) {
                posicion = i;
            }
            i++;
        }
        return posicion;
    }

    
    public int buscarBinarioPorNombre(String nombre) {
        int posicion = -1;
        int ini = 0;
        int fin = aspirantes.size() - 1;

         
        this.ordenarPorNombre();
        while (ini <= fin) {
            int m = (ini + fin) / 2;
            if (aspirantes.get(m).darNombre().compareToIgnoreCase(nombre) < 0) {
                System.out.println("Entro a la menor");
                ini = m +1;
            }
            else if (aspirantes.get(m).darNombre().compareToIgnoreCase(nombre) > 0) {
                System.out.println("Entro a la mayor");
                fin = m - 1;
            } else {
                posicion = m;
                return posicion;
            }
        }

        return posicion;
    }


  
    public int buscarAspiranteMasJoven() {
        int posicion = -1;
 
        if (this.aspirantes.size() != 0) {
        posicion = 0;
        int i = 0;
        for (Aspirante a: aspirantes) {
            if (a.darEdad() < this.aspirantes.get(posicion).darEdad()) {
                posicion = i;
            }
            i++;
        }
        }

        return posicion;
    }

    
    public int buscarAspiranteMayorEdad() {
        int posicion = -1;

       
        if (this.aspirantes.size() != 0) {
            posicion = 0;
            int i = 0;
            for (Aspirante a: aspirantes) {
                if (a.darEdad() > this.aspirantes.get(posicion).darEdad()) {
                    posicion = i;
                }
                i++;
            }
        }

        return posicion;
    }
    public int buscarAspirantePorCedula(String cedula) {
        int posicion = -1;
        int i = 0;
        for (Aspirante a : aspirantes) {
            if (a.darCedula().equalsIgnoreCase(cedula)) {
                posicion = i;
            }
            i++;
        }
        return posicion;
    }   
  
    public int buscarAspiranteMayorExperiencia() {
        int posicion = -1;

        // TODO: Realizar el ejercicio correspondiente
        if (this.aspirantes.size() != 0) {
            posicion = 0;
            int i = 0;
            for (Aspirante a: aspirantes) {
                if (a.darAniosExperiencia() > this.aspirantes.get(posicion).darAniosExperiencia()) {
                    posicion = i;
                }
                i++;
            }
        }

        return posicion;
    }

   
    public boolean contratarAspirante(String nombre) {
        boolean contratado = false;

        // TODO: Realizar el ejercicio correspondiente
        System.out.println( this.aspirantes.get(0));
        if (nombre != null) {
        int i = 0;
        for (Aspirante a: aspirantes) {
            if(a.darNombre().equalsIgnoreCase(nombre)) {
                this.aspirantes.remove(i);
                contratado = true;
                break;
            }
            i++;

        }
        }
        return contratado;
    }

    
    public int eliminarAspirantesPorExperiencia(int aniosExperiencia) {
        int eliminados = 0;
        int cont = 0;

        
        if (aniosExperiencia >= 0) {
            ArrayList<Integer> indexAEliminar = new ArrayList<>();
 
            for (Aspirante a: aspirantes) {
                if(a.darAniosExperiencia() < aniosExperiencia) {
                    indexAEliminar.add(cont);
                }
                cont++;

            }

          
            if (indexAEliminar.size() > 0) {
                int j = 0;
                for (int index : indexAEliminar) {
                    this.aspirantes.remove(index - j);
                    j = 1;
                }
            }
            eliminados = indexAEliminar.size();
            System.out.println(indexAEliminar);
        }
        return eliminados;
    }

}