
package universidadean.empleo.mundo;

public class Aspirante {

    // -----------------------------------------------------------------
    // Constantes
    // -----------------------------------------------------------------

    public static final String ADMINISTRADOR = "Administrador";

    public static final String INGENIERO_INDUSTRIAL = "Ingeniero Industrial";
    public static final String INGENIERO_SISTEMAS = "Ingeniero de Sistemas";
    public static final String DISEÑADOR_GRAFICO = "Diseñador Grafico";
    public static final String INGENIERO_SOFTWARE = "Ingeniero de Software";
    public static final String ANALISTA_DATOS = "Analista de Datos";
    public static final String GERENTE_PROYECTOS = "Gerente de Proyectos";

  
    public static final String CONTADOR = "Contador";
    public static final String ECONOMISTA = "Economista";

    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

    private String nombre;
    private String profesion;
    private int aniosExperiencia;
    private int edad;
    private String telefono;
    private String imagen;
    private String cedula;


    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------


    public Aspirante(String nombreA, String profesionA, int aniosExperienciaA, int edadA, String telefonoA, String imagenA, String cedulaA) {
        nombre = nombreA;
        profesion = profesionA;
        aniosExperiencia = aniosExperienciaA;
        edad = edadA;
        telefono = telefonoA;
        imagen = imagenA;
        cedula = cedulaA;
    }

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------

    public String darNombre() {
        return nombre;
    }

    public String darProfesion() {
        return profesion;
    }

    public int darAniosExperiencia() {
        return aniosExperiencia;
    }

    public int darEdad() {
        return edad;
    }

    public String darTelefono() {
        return telefono;
    }

    public String darImagen() {
        return imagen;
    } 

    public String darCedula() {
        return cedula; 
    }

    public void cambiarCedula(String cedulaA) {
        this.cedula = cedulaA; 
        
    }    

    public String toString() {
       return nombre + " - " + profesion + " - Cédula: " + cedula;
    }
}