
package universidadean.empleo.interfaz;

import universidadean.empleo.mundo.Aspirante;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;


public class PanelLista extends JPanel implements ListSelectionListener {
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

  
    private InterfazBolsaDeEmpleo principal;

    // -----------------------------------------------------------------
    // Atributos de la Interfaz
    // -----------------------------------------------------------------
    Color amarilloPastel = new Color(255, 255, 150);

    private JList listaAspirantes;

    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------
    
    public PanelLista(InterfazBolsaDeEmpleo interfaz) {
        principal = interfaz;

        setLayout(new BorderLayout());
        setBorder(new TitledBorder("Aspirantes Registrados en la Bolsa"));

        listaAspirantes = new JList();
        listaAspirantes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaAspirantes.addListSelectionListener(this);
        

        JScrollPane scroll = new JScrollPane();
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.setBorder(new CompoundBorder(new EmptyBorder(3, 3, 3, 3), new LineBorder(Color.BLACK, 1)));
        scroll.getViewport().add(listaAspirantes);
        

        add(scroll, BorderLayout.CENTER);

    }

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------
    public void actualizarLista(ArrayList<Aspirante> listaActualizada) {
        listaAspirantes.setListData(listaActualizada.toArray());
        listaAspirantes.setSelectedIndex(0);
    }

    public void seleccionar(int seleccionado) {
        listaAspirantes.setSelectedIndex(seleccionado);
        listaAspirantes.ensureIndexIsVisible(seleccionado);
    }

    public void valueChanged(ListSelectionEvent evento) {
        if (listaAspirantes.getSelectedValue() != null) {
            Aspirante aspiranteSeleccionado = (Aspirante) listaAspirantes.getSelectedValue();
            principal.verDatos(aspiranteSeleccionado);
        }
    }

    
    public boolean haySeleccionado() {
        return !listaAspirantes.isSelectionEmpty();
    }

    public String darNombreSeleccionado() {
        String nombre = null;

        if (listaAspirantes.getSelectedValue() != null) {
            Aspirante aspiranteSeleccionado = (Aspirante) listaAspirantes.getSelectedValue();
            nombre = aspiranteSeleccionado.darNombre();
        }

        return nombre;
    }

}