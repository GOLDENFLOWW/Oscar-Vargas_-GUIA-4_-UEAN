
package universidadean.empleo.interfaz;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

 
public class PanelExtension extends JPanel implements ActionListener {
    // -----------------------------------------------------------------
    // Constantes
    // -----------------------------------------------------------------
    private final String OPCION_1 = "Salir";
    Color amarilloPastel = new Color(255, 255, 210);
    Color amarilloPastel2 = new Color(255, 255, 150);
    private InterfazBolsaDeEmpleo principal;

    // -----------------------------------------------------------------
    // Atributos de la Interfaz
    // -----------------------------------------------------------------

   
    private JButton botonOpcion1;

    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------

   
    public PanelExtension(InterfazBolsaDeEmpleo interfaz) {
        principal = interfaz;
        inicializar();
    }

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------

   
    private void inicializar() {
        setBorder(new TitledBorder("Opciones del programa"));

        setLayout(new FlowLayout());
        botonOpcion1 = new JButton("Salir");
        botonOpcion1.setActionCommand(OPCION_1);
        botonOpcion1.addActionListener(this);
        botonOpcion1.setBackground(amarilloPastel2); // Agregar esta línea

        add(botonOpcion1);
    }

    
    public void actionPerformed(ActionEvent evento) {
        String comando = evento.getActionCommand();
        if (OPCION_1.equals(comando)) {
            principal.reqFuncOpcion1();
        }
    }

}