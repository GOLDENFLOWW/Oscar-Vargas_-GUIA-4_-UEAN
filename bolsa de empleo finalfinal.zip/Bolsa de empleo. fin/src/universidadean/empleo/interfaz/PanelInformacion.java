
package universidadean.empleo.interfaz;

import universidadean.empleo.mundo.Aspirante;
import java.awt.Color;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;



public class PanelInformacion extends JPanel {


    Color amarilloPastel = new Color(255, 255, 204);
 
    private static final int ALTURA = 125;

  
    private static final int ANCHO = 200;

    private static final String IMANGEN_VACIA = "./data/vacia.jpg";

    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------


    private ImageIcon imagenVacia;

    // -----------------------------------------------------------------
    // Atributos de la Interfaz
    // -----------------------------------------------------------------


    private JLabel txtProfesion;
    
    private JLabel txtCedula;
   
    private JLabel txtAniosExperiencia;

  
    private JLabel txtTelefono;

  
    private JLabel txtEdad;

 
    private JLabel txtNombre;

   
    private JLabel etiquetaProfesion;

   
    private JLabel etiquetaAniosExperiencia;

   
    private JLabel etiquetaTelefono;

   
    private JLabel etiquetaEdad;
    
    private JLabel etiquetaCedula;
    
    private JLabel etiquetaNombre;

   
    private JLabel etiquetaImagen;

    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------

   
    public PanelInformacion() {
        setBorder(new TitledBorder("Datos del Aspirante"));
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridheight = 5;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(0, 0, 0, 10);

        etiquetaImagen = new JLabel(); 
        add(etiquetaImagen, gbc);

        etiquetaNombre = new JLabel("Nombre: ");
        gbc.gridx = 1;
        gbc.gridheight = 1;
        gbc.insets = new Insets(0, 0, 5, 0);
        add(etiquetaNombre, gbc);

        txtNombre = new JLabel();
        txtNombre.setPreferredSize(new Dimension(140, 20));
        gbc.gridx = 2;
        add(txtNombre, gbc);

        etiquetaEdad = new JLabel("Edad: ");
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(etiquetaEdad, gbc);

        txtEdad = new JLabel();
        txtEdad.setPreferredSize(new Dimension(140, 20));
        gbc.gridx = 2;
        add(txtEdad, gbc);

        etiquetaProfesion = new JLabel("Profesión: ");
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(etiquetaProfesion, gbc);

        txtProfesion = new JLabel();
        txtProfesion.setPreferredSize(new Dimension(140, 20));
        gbc.gridx = 2;
        add(txtProfesion, gbc);

        etiquetaAniosExperiencia = new JLabel("Experiencia: ");
        gbc.gridx = 1;
        gbc.gridy = 3;
        add(etiquetaAniosExperiencia, gbc);

        txtAniosExperiencia = new JLabel();
        txtAniosExperiencia.setPreferredSize(new Dimension(140, 20));
        gbc.gridx = 2;
        add(txtAniosExperiencia, gbc);

        etiquetaTelefono = new JLabel("Teléfono: ");
        gbc.gridx = 1;
        gbc.gridy = 4;
        add(etiquetaTelefono, gbc);

        txtTelefono = new JLabel();
        txtTelefono.setPreferredSize(new Dimension(140, 20));
        gbc.gridx = 2;
        add(txtTelefono, gbc);

        etiquetaCedula = new JLabel("Cédula:");
        gbc.gridx = 1;
        gbc.gridy = 5; // Ajusta según sea necesario
        add(etiquetaCedula, gbc);

        txtCedula = new JLabel(); 
        txtCedula.setPreferredSize(new Dimension(140, 20));
        gbc.gridx = 2;
        add(txtCedula, gbc);
        
          imagenVacia = new ImageIcon(IMANGEN_VACIA);
    }

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------

    public void mostrarDatos(Aspirante aspirante) {
        try {
            txtProfesion.setText(aspirante.darProfesion());
            txtAniosExperiencia.setText(String.valueOf(aspirante.darAniosExperiencia() + " año(s)"));
            String imagen = aspirante.darImagen();
            BufferedImage bImagen = ImageIO.read(new File(imagen));

            Image laImagen = bImagen.getScaledInstance((int) (ANCHO), (int) (ALTURA), Image.SCALE_AREA_AVERAGING); 
            etiquetaImagen.setIcon(new ImageIcon(laImagen));
            txtTelefono.setText(aspirante.darTelefono());
            txtEdad.setText(String.valueOf(aspirante.darEdad() + " años"));
            txtNombre.setText(aspirante.darNombre());

            if (aspirante.darCedula() == null || aspirante.darCedula().isEmpty()) {
                txtCedula.setText("Cédula no disponible");
            } else {
                txtCedula.setText(aspirante.darCedula());
            }

            validate();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar la imagen del aspirante " + aspirante.darNombre(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void limpiarDatos() {
        txtProfesion.setText("");
        txtAniosExperiencia.setText("");
        etiquetaImagen.setIcon(imagenVacia);
        txtTelefono.setText("");
        txtEdad.setText("");
        txtNombre.setText("");
        txtCedula.setText("");
    }
}