
package universidadean.empleo.interfaz;

import universidadean.empleo.persistencia.ControladoraPersistencia;


public class pruebaBD {
     public static void main(String[] args) {
        ControladoraPersistencia controlPers = new ControladoraPersistencia();
    }
    
}
