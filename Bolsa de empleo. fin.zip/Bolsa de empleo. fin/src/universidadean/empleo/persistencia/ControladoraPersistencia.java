
package universidadean.empleo.persistencia;



public class ControladoraPersistencia {
    
    AspiranteJpaController aspJpa = new AspiranteJpaController();
}
    
    
    

   
    
 
