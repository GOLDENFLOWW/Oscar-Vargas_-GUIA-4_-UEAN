package universidadean.empleo.mundo;

import javax.annotation.processing.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="org.eclipse.persistence.internal.jpa.modelgen.CanonicalModelProcessor", date="2024-09-28T22:49:55", comments="EclipseLink-2.7.12.v20230209-rNA")
@StaticMetamodel(Aspirante.class)
public class Aspirante_ { 

    public static volatile SingularAttribute<Aspirante, Integer> aniosExperiencia;
    public static volatile SingularAttribute<Aspirante, String> cedula;
    public static volatile SingularAttribute<Aspirante, String> profesion;
    public static volatile SingularAttribute<Aspirante, String> telefono;
    public static volatile SingularAttribute<Aspirante, String> nombre;
    public static volatile SingularAttribute<Aspirante, Integer> edad;

}